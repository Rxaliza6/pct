<footer class="footer">
  <div class="container-fluid">
    <div class="copyright ml-4">
      2023, made with <i class="fa-solid fa-heart fa-beat px-1 py-1" style="color: #ffffff;"></i> by <a href="https://www.instagram.com/rizagi_6/" target="_blank">Ricky Inzagi Baryono</a>
    </div>				
  </div>
</footer>